<div class="header">
    <div class="nav">
        <div class="brand-name">
            <a href="../index.php" class="logo">triptrip</a>
        </div>
        <a href="../services/_logout.php" class="btn">Logout</a>
    </div>
</div>