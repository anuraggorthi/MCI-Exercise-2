function togglebtn(){
    $("#navBar").toggleClass("hidemenu");
}